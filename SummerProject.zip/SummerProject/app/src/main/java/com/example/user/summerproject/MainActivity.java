package com.example.user.summerproject;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.support.constraint.ConstraintLayout;
import android.view.View;
import android.widget.ImageView;
import android.widget.TableRow;

public class MainActivity extends Activity {
    private ConstraintLayout[] m_lytFragments;
    private ImageView[] m_imgMenu;

    private Bitmap[] m_bmpMenuDisable;
    private Bitmap[] m_bmpMenuEnable;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        m_lytFragments = new ConstraintLayout[] {
                findViewById(R.id.MainActivity_Layout_Monthly),
                findViewById(R.id.MainActivity_Layout_Weekly),
                findViewById(R.id.MainActivity_Layout_Share),
                findViewById(R.id.MainActivity_Layout_Info)
        };

        m_imgMenu = new ImageView[] {
                findViewById(R.id.MainActivity_ImageView_Monthly),
                findViewById(R.id.MainActivity_ImageView_Weekly),
                findViewById(R.id.MainActivity_ImageView_Share),
                findViewById(R.id.MainActivity_ImageView_Info)
        };

        m_bmpMenuDisable = new Bitmap[] {
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_monthly_not_select),
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_weekly_not_select),
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_share_not_select),
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_info_not_select)
        };

        m_bmpMenuEnable = new Bitmap[] {
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_monthly_select),
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_weekly_select),
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_share_select),
                BitmapFactory.decodeResource(getResources(), R.drawable.ic_info_select)
        };

        for (ImageView iv : m_imgMenu)
            iv.setOnClickListener(ButtonListener);
    }

    private void onSelectMenu(int number) {
        for (int i = 0; i < 4; i++) {
            m_lytFragments[i].setVisibility(i == number ? View.VISIBLE : View.INVISIBLE);
            m_imgMenu[i].setImageBitmap(i == number ? m_bmpMenuEnable[i] : m_bmpMenuDisable[i]);
        }
    }
    private final View.OnClickListener ButtonListener = new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            switch (view.getId()) {
                case R.id.MainActivity_ImageView_Monthly:
                    onSelectMenu(0);
                    break;
                case R.id.MainActivity_ImageView_Weekly:
                    onSelectMenu(1);
                    break;
                case R.id.MainActivity_ImageView_Share:
                    onSelectMenu(2);
                    break;
                case R.id.MainActivity_ImageView_Info:
                    onSelectMenu(3);
                    break;
            }
        }
    };
}